import "./products.scss";

export default function Products() {
  return <div className="products">Product page</div>;
}
