export const home = "/";
export const products = "/products";
export const about = "/about";
