import "./about.scss";

export default function About() {
  return <div className="about">About Page</div>;
}
